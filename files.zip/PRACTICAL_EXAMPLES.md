# 🔧 PRACTICAL USAGE GUIDE - Real-World Examples

## Before Starting

Make sure:
```bash
docker-compose up -d
# Wait for message: "AI Agent System initialized successfully!"
```

Then test:
```bash
curl http://localhost:8000/api/health
# Should return: {"status": "healthy", ...}
```

---

## 📚 EXAMPLE 1: RESEARCH A TOPIC

### Scenario
You need to research artificial intelligence for a project.

### Method 1: Using curl
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Research the current state of artificial intelligence, including recent breakthroughs, applications, and challenges",
    "priority": 5
  }'
```

### Method 2: Using Browser
1. Go to http://localhost:8000/docs
2. Scroll down and find "POST /api/tasks"
3. Click "Try it out"
4. Paste the JSON above
5. Click "Execute"

### What Happens
- Planner receives task
- Routes to Research Agent
- Research Agent gathers information
- Summarizes findings
- Returns comprehensive research

### Check Results
```bash
# Get the task_id from response
curl "http://localhost:8000/api/tasks/{task_id}"

# Repeat until status is "completed"
```

---

## 💻 EXAMPLE 2: GENERATE CODE

### Scenario
You need Python code to process CSV files.

### Request
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Write Python code to read a CSV file, clean the data, and calculate basic statistics",
    "priority": 4,
    "metadata": {
      "language": "python",
      "task_type": "generate"
    }
  }'
```

### What You Get
The Coding Agent will:
1. Generate complete Python code
2. Include error handling
3. Add helpful comments
4. Show usage examples
5. Follow best practices

### Expected Output
```
Python code file with:
- CSV reading functionality
- Data cleaning functions
- Statistics calculation
- Example usage
- Comprehensive comments
```

---

## ✍️ EXAMPLE 3: WRITE AN ARTICLE

### Scenario
You need a technical article about cloud computing.

### Request
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Write a comprehensive technical article about cloud computing, including AWS, Azure, and Google Cloud, with examples and best practices",
    "priority": 3,
    "metadata": {
      "article_type": "technical",
      "length": "medium"
    }
  }'
```

### Output Includes
- Compelling headline
- Introduction with hook
- 3-5 main sections
- Real-world examples
- Best practices
- Conclusion
- Professional formatting

---

## 📊 EXAMPLE 4: ANALYZE DATA

### Scenario
You have quarterly sales data and need analysis.

### Request
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Analyze the quarterly sales data and identify trends, growth patterns, and provide insights",
    "priority": 4,
    "metadata": {
      "data": {
        "Q1": 150000,
        "Q2": 180000,
        "Q3": 165000,
        "Q4": 220000,
        "quarters": ["Q1 2024", "Q2 2024", "Q3 2024", "Q4 2024"]
      },
      "analysis_type": "statistical"
    }
  }'
```

### What Data Agent Does
1. Analyzes patterns
2. Calculates growth rates
3. Identifies trends
4. Provides insights
5. Suggests visualizations

### Expected Analysis
- Trend identification
- Growth analysis
- Statistical insights
- Visualization recommendations

---

## 🔄 EXAMPLE 5: DESIGN A WORKFLOW

### Scenario
You need to automate daily report generation.

### Request
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Design an automated workflow that collects data from multiple sources, analyzes it, generates a report, and emails it daily at 9 AM",
    "priority": 5,
    "metadata": {
      "schedule": "daily",
      "time": "09:00"
    }
  }'
```

### Automation Agent Provides
- Complete workflow design
- Step-by-step process
- Integration points
- Error handling
- Implementation recommendations

---

## 🎓 EXAMPLE 6: MINING ENGINEERING RESEARCH

### Scenario
Research open-pit mining safety.

### Request
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Research current best practices and regulations for open-pit mining safety, including equipment, procedures, and hazard management",
    "priority": 5
  }'
```

### Output
- Safety best practices
- Regulatory requirements
- Equipment standards
- Hazard identification
- Procedure recommendations
- Recent developments

---

## 📈 EXAMPLE 7: COMPLEX MULTI-AGENT TASK

### Scenario
You need research, code, AND an article.

### Request
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Research machine learning algorithms, write Python code implementing at least two popular algorithms, and create a technical article explaining when and why to use each one",
    "priority": 5
  }'
```

### What Happens
1. **Planner** analyzes the complex task
2. **Breaks into subtasks:**
   - Research task → **Research Agent**
   - Code task → **Coding Agent**
   - Writing task → **Content Agent**
3. **Parallel execution** of all three
4. **Synthesis** of all results
5. **Final comprehensive output**

---

## 🔍 EXAMPLE 8: CODE DEBUGGING

### Scenario
You have buggy Python code that needs fixing.

### Request
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Debug this Python code that should calculate factorial but returns wrong results",
    "priority": 4,
    "metadata": {
      "code": "def factorial(n):\n    if n == 0:\n        return 1\n    return n * factorial(n)",
      "error": "RecursionError: maximum recursion depth exceeded"
    }
  }'
```

### Coding Agent Will
1. Identify the bug (missing -1 in recursion)
2. Fix the code
3. Explain what was wrong
4. Provide correct version

---

## 📋 EXAMPLE 9: DATA CLEANING RECOMMENDATIONS

### Scenario
Your dataset has issues.

### Request
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Analyze this dataset for data quality issues and provide cleaning recommendations",
    "priority": 4,
    "metadata": {
      "data": {
        "names": ["John", "jane", "", "JOHN", "Jane"],
        "ages": [25, 30, null, 25, -5],
        "emails": ["john@example.com", "jane@example.com", "invalid", "john@example.com", "jane@example"]
      }
    }
  }'
```

### Data Agent Identifies
- Inconsistent capitalization
- Missing values
- Invalid data types
- Duplicates
- Format issues

---

## 🌐 EXAMPLE 10: CONTENT OPTIMIZATION

### Scenario
You have an article that needs improvement.

### Request
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Optimize this article for clarity and engagement, making it more professional and easier to understand",
    "priority": 3,
    "metadata": {
      "content": "Machine learning is when computers learn. It is important. You can use it for many things.",
      "optimization_goal": "clarity"
    }
  }'
```

### Content Agent Improves
- Clarity and readability
- Professionalism
- Engagement
- Grammar and style

---

## 🔗 EXAMPLE 11: INTEGRATION PLANNING

### Scenario
Plan Salesforce to Slack integration.

### Request
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Design a bi-directional integration between Salesforce and Slack that syncs customer updates and notifications",
    "priority": 5,
    "metadata": {
      "system_a": "Salesforce",
      "system_b": "Slack",
      "sync_type": "bi-directional"
    }
  }'
```

### Output Includes
- Data mapping
- Sync strategy
- Authentication
- Error handling
- Monitoring
- Implementation steps

---

## 📝 EXAMPLE 12: BATCH PROCESSING DESIGN

### Scenario
Design batch processing for 100K records.

### Request
```bash
curl -X POST "http://localhost:8000/api/tasks" \
  -H "Content-Type: application/json" \
  -d '{
    "description": "Design an efficient batch processing system to process 100,000 customer records daily, including validation, transformation, and loading",
    "priority": 5,
    "metadata": {
      "batch_size": 1000
    }
  }'
```

### System Provides
- Batch strategy
- Performance optimization
- Error handling
- Resource management
- Implementation guide

---

## 🚀 HOW TO RUN EXAMPLES LOCALLY

Instead of curl, you can run Python examples:

```bash
# Run all examples
python examples.py

# Or in Python directly
import asyncio
from agents.planner_agent import PlannerAgent
from agents.research_agent import ResearchAgent
from agents.base_agent import TaskContext

async def main():
    planner = PlannerAgent()
    planner.register_agent(ResearchAgent())
    await planner.initialize()
    
    context = TaskContext(
        task_id="custom-001",
        user_input="Research AI trends"
    )
    
    result = await planner.process(context)
    print(result)

asyncio.run(main())
```

---

## 🎯 TESTING AGENTS INDIVIDUALLY

Test each agent without the planner:

### Test Research Agent
```bash
curl -X POST "http://localhost:8000/api/agents/research/test" \
  -H "Content-Type: application/json" \
  -d '{"description": "Research blockchain technology"}'
```

### Test Coding Agent
```bash
curl -X POST "http://localhost:8000/api/agents/coding/test" \
  -H "Content-Type: application/json" \
  -d '{"description": "Write Python code for sorting"}'
```

### Test Content Agent
```bash
curl -X POST "http://localhost:8000/api/agents/content/test" \
  -H "Content-Type: application/json" \
  -d '{"description": "Write an article about Python"}'
```

---

## 📊 MONITORING TASKS

### See All Running Tasks
```bash
curl "http://localhost:8000/api/tasks?status=processing"
```

### See Completed Tasks
```bash
curl "http://localhost:8000/api/tasks?status=completed"
```

### See Failed Tasks
```bash
curl "http://localhost:8000/api/tasks?status=failed"
```

### Get Statistics
```bash
curl "http://localhost:8000/api/stats"
```

---

## 💡 PRO TIPS

### Tip 1: Use Metadata for Better Results
```json
{
  "description": "Generate code",
  "metadata": {
    "language": "python",
    "style": "clean and documented",
    "purpose": "data processing"
  }
}
```

### Tip 2: Check Agent Info
```bash
curl "http://localhost:8000/api/agents/research"
```

### Tip 3: Save Task IDs
Copy task IDs to check later:
```bash
echo "task-id-here" > my_tasks.txt
```

### Tip 4: Use Priority
- 5: Urgent
- 4: Important
- 3: Normal
- 2: Low
- 1: Very Low

### Tip 5: Monitor Logs
```bash
docker-compose logs -f api
```

---

## ⚠️ COMMON ISSUES & FIXES

### Task is taking too long
```bash
# Check logs
docker-compose logs api | tail -20

# Can take 30-60 seconds for complex tasks
# This is normal
```

### Wrong results
```bash
# Check task metadata
curl "http://localhost:8000/api/tasks/{id}" | grep metadata

# May need more specific description
```

### API not responding
```bash
# Check health
curl http://localhost:8000/api/health

# Restart if needed
docker-compose restart api
```

---

## 🎓 PRACTICE EXERCISES

### Exercise 1: Research
Research a topic you're studying for mining engineering and save the output.

### Exercise 2: Code Generation
Generate code to process mining data.

### Exercise 3: Report
Generate a technical report on a mining topic.

### Exercise 4: Data Analysis
Analyze some sample mining production data.

### Exercise 5: Integration
Design a workflow for mining site operations.

---

## 📚 NEXT STEPS

1. **Try Example 1** - Research task (easiest)
2. **Try Example 2** - Code generation (fun)
3. **Try Example 3** - Writing (useful)
4. **Try Example 4** - Data analysis (practical)
5. **Try Example 7** - Complex task (powerful)
6. **Try Example 6** - Mining task (relevant to you)

---

**All examples are real, functional, and ready to use!**
